let arrow = document.getElementById("arrow-back");
let category = document.getElementById("category");
let h1 = document.getElementsByTagName("h1")[0];
let main = document.getElementsByClassName("main")[0];
let footer = document.getElementsByTagName("footer")[0];
let cartButton = document.getElementById("cart-button");
let cart = document.getElementsByClassName("cart")[0];

let items = document.getElementsByClassName("grid-item");

for (let i = 0; i < items.length; i++) {
    items[i].onclick = function () {
        cartButton.style.display = "block";
        category.style.display = "block";
        arrow.style.display = "block";
        h1.innerText = "T-Shirts";

        main.style.display = "none";

        footer.style.marginTop = "600px";
    };
}

cartButton.onclick = function () {
    h1.innerText = "Your Cart";
    cart.style.display = "block";
    arrow.style.display = "block";

    cartButton.style.display = "none";
    category.style.display = "none";
    main.style.display = "none";

    footer.style.marginTop = "560px";
};

arrow.onclick = function () {
    h1.innerText = "Shopping Cart - Make Purchases now!";
    cart.style.display = "none";
    cartButton.style.display = "block";
    category.style.display = "none";
    arrow.style.display = "none";

    main.style.display = "block";
    footer.style.marginTop = "0";
};